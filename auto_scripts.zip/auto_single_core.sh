# Run each numactl command with --physcpubind=10 and redirect output to individual log files

numactl --physcpubind=10 python3 dlrm_s_pytorch.py \
    --arch-embedding-size=10000000-10000000-10000000-10000000-10000000-10000000-10000000-10000000 \
    --arch-sparse-feature-size=64 --arch-mlp-bot="512-512-64" --arch-mlp-top="1024-1024-1024-1" \
    --data-generation=random --mini-batch-size=2048 --num-batches=100 --num-indices-per-lookup=100 \
    --print-freq=200 --print-time --enable-profiling > auto_single1.log 2>&1

numactl --physcpubind=10 python3 dlrm_s_pytorch.py \
    --arch-embedding-size=10000000-10000000-10000000-10000000-10000000-10000000-10000000-10000000 \
    --arch-sparse-feature-size=64 --arch-mlp-bot="512-512-64" --arch-mlp-top="1024-1024-1024-1" \
    --data-generation=random --mini-batch-size=2048 --num-batches=300 --num-indices-per-lookup=100 \
    --print-freq=200 --print-time --enable-profiling > auto_single2.log 2>&1

numactl --physcpubind=10 python3 dlrm_s_pytorch.py \
    --arch-embedding-size=10000000-10000000-10000000-10000000-10000000-10000000-10000000-10000000 \
    --arch-sparse-feature-size=64 --arch-mlp-bot="512-512-64" --arch-mlp-top="1024-1024-1024-1" \
    --data-generation=random --mini-batch-size=2048 --num-batches=500 --num-indices-per-lookup=100 \
    --print-freq=200 --print-time --enable-profiling > auto_single3.log 2>&1

numactl --physcpubind=10 python3 dlrm_s_pytorch.py \
    --arch-embedding-size=10000000-10000000-10000000-10000000-10000000-10000000-10000000-10000000 \
    --arch-sparse-feature-size=64 --arch-mlp-bot="512-512-64" --arch-mlp-top="1024-1024-1024-1" \
    --data-generation=random --mini-batch-size=2048 --num-batches=100 --num-indices-per-lookup=300 \
    --print-freq=200 --print-time --enable-profiling > auto_single4.log 2>&1

numactl --physcpubind=10 python3 dlrm_s_pytorch.py \
    --arch-embedding-size=10000000-10000000-10000000-10000000-10000000-10000000-10000000-10000000 \
    --arch-sparse-feature-size=64 --arch-mlp-bot="512-512-64" --arch-mlp-top="1024-1024-1024-1" \
    --data-generation=random --mini-batch-size=2048 --num-batches=100 --num-indices-per-lookup=500 \
    --print-freq=200 --print-time --enable-profiling > auto_single5.log 2>&1

numactl --physcpubind=10 python3 dlrm_s_pytorch.py \
    --arch-embedding-size=10000000-10000000-10000000-10000000-10000000-10000000-10000000-10000000 \
    --arch-sparse-feature-size=64 --arch-mlp-bot="512-512-64" --arch-mlp-top="1024-1024-1024-1" \
    --data-generation=random --mini-batch-size=1024 --num-batches=100 --num-indices-per-lookup=100 \
    --print-freq=200 --print-time --enable-profiling > auto_single6.log 2>&1

numactl --physcpubind=10 python3 dlrm_s_pytorch.py \
    --arch-embedding-size=10000000-10000000-10000000-10000000-10000000-10000000-10000000-10000000 \
    --arch-sparse-feature-size=64 --arch-mlp-bot="512-512-64" --arch-mlp-top="1024-1024-1024-1" \
    --data-generation=random --mini-batch-size=512 --num-batches=100 --num-indices-per-lookup=100 \
    --print-freq=200 --print-time --enable-profiling > auto_single7.log 2>&1

numactl --physcpubind=10 python3 dlrm_s_pytorch.py \
    --arch-embedding-size=10000000-10000000-10000000-10000000-10000000-10000000-10000000-10000000 \
    --arch-sparse-feature-size=64 --arch-mlp-bot="512-512-64" --arch-mlp-top="1024-1024-1024-1" \
    --data-generation=random --mini-batch-size=256 --num-batches=100 --num-indices-per-lookup=100 \
    --print-freq=200 --print-time --enable-profiling > auto_single8.log 2>&1

numactl --physcpubind=10 python3 dlrm_s_pytorch.py \
    --arch-embedding-size=10000000-10000000-10000000-10000000-10000000-10000000-10000000-10000000 \
    --arch-sparse-feature-size=64 --arch-mlp-bot="512-512-64" --arch-mlp-top="1024-1024-1024-1" \
    --data-generation=random --mini-batch-size=128 --num-batches=100 --num-indices-per-lookup=100 \
    --print-freq=200 --print-time --enable-profiling > auto_single9.log 2>&1

numactl --physcpubind=10 python3 dlrm_s_pytorch.py \
    --arch-embedding-size=10000000-10000000-10000000-10000000-10000000-10000000-10000000-10000000 \
    --arch-sparse-feature-size=64 --arch-mlp-bot="512-512-64" --arch-mlp-top="1024-1024-1024-1" \
    --data-generation=random --mini-batch-size=64 --num-batches=100 --num-indices-per-lookup=100 \
    --print-freq=200 --print-time --enable-profiling > auto_single10.log 2>&1

