numactl python3 dlrm_s_pytorch.py \
                          --arch-embedding-size=1000000-1000000-1000000-1000000-1000000-1000000-1000000-1000000 \
                          --arch-sparse-feature-size=64 --arch-mlp-bot="512-512-64" --arch-mlp-top="1024-1024-1024-1" \
                          --data-generation=random --mini-batch-size=2048 --num-batches=1000 --num-indices-per-lookup=100 \
                          --print-freq=200 --print-time --enable-profiling > op5.log


numactl python3 dlrm_s_pytorch.py \
                          --arch-embedding-size=10000000-10000000-10000000-10000000-10000000-10000000-10000000-10000000 \
                          --arch-sparse-feature-size=64 --arch-mlp-bot="512-512-64" --arch-mlp-top="1024-1024-1024-1" \
                          --data-generation=random --mini-batch-size=2048 --num-batches=1000 --num-indices-per-lookup=100 \
                          --print-freq=200 --print-time --enable-profiling > op6.log



numactl python3 dlrm_s_pytorch.py \
                          --arch-embedding-size=20000000-20000000-20000000-20000000-10000000-10000000-10000000-10000000 \
                          --arch-sparse-feature-size=64 --arch-mlp-bot="512-512-64" --arch-mlp-top="1024-1024-1024-1" \
                          --data-generation=random --mini-batch-size=2048 --num-batches=1000 --num-indices-per-lookup=100 \
                          --print-freq=200 --print-time --enable-profiling > op7.log

numactl python3 dlrm_s_pytorch.py \
                          --arch-embedding-size=20000000-20000000-20000000-20000000-20000000-20000000-20000000-20000000 \
                          --arch-sparse-feature-size=64 --arch-mlp-bot="512-512-64" --arch-mlp-top="1024-1024-1024-1" \
                          --data-generation=random --mini-batch-size=2048 --num-batches=1000 --num-indices-per-lookup=100 \
                          --print-freq=200 --print-time --enable-profiling > op8.log