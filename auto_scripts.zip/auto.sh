# Run each numactl command and redirect output to individual log files

# numactl python3 dlrm_s_pytorch.py \
#     --arch-embedding-size=10000000-10000000-10000000-10000000-10000000-10000000-10000000-10000000 \
#     --arch-sparse-feature-size=64 --arch-mlp-bot="512-512-64" --arch-mlp-top="1024-1024-1024-1" \
#     --data-generation=random --mini-batch-size=2048 --num-batches=100 --num-indices-per-lookup=100 \
#     --print-freq=200 --print-time --enable-profiling > auto1.log 2>&1
 
# numactl python3 dlrm_s_pytorch.py \
#     --arch-embedding-size=10000000-10000000-10000000-10000000-10000000-10000000-10000000-10000000 \
#     --arch-sparse-feature-size=64 --arch-mlp-bot="512-512-64" --arch-mlp-top="1024-1024-1024-1" \
#     --data-generation=random --mini-batch-size=2048 --num-batches=300 --num-indices-per-lookup=100 \
#     --print-freq=200 --print-time --enable-profiling > auto2.log 2>&1

# numactl python3 dlrm_s_pytorch.py \
#     --arch-embedding-size=10000000-10000000-10000000-10000000-10000000-10000000-10000000-10000000 \
#     --arch-sparse-feature-size=64 --arch-mlp-bot="512-512-64" --arch-mlp-top="1024-1024-1024-1" \
#     --data-generation=random --mini-batch-size=2048 --num-batches=500 --num-indices-per-lookup=100 \
#     --print-freq=200 --print-time --enable-profiling > auto3.log 2>&1

# numactl python3 dlrm_s_pytorch.py \
#     --arch-embedding-size=10000000-10000000-10000000-10000000-10000000-10000000-10000000-10000000 \
#     --arch-sparse-feature-size=64 --arch-mlp-bot="512-512-64" --arch-mlp-top="1024-1024-1024-1" \
#     --data-generation=random --mini-batch-size=2048 --num-batches=100 --num-indices-per-lookup=300 \
#     --print-freq=200 --print-time --enable-profiling > auto4.log 2>&1

# numactl --physcpubind=10  python3 dlrm_s_pytorch.py \
#                           --arch-embedding-size=20000000-20000000-20000000-20000000-10000000-10000000-10000000-10000000 \
#                           --arch-sparse-feature-size=64 --arch-mlp-bot="512-512-64" --arch-mlp-top="1024-1024-1024-1" \
#                           --data-generation=random --mini-batch-size=2048 --num-batches=1000 --num-indices-per-lookup=100 \
#                           --print-freq=200 --print-time --enable-profiling > mem1.log

numactl python3 dlrm_s_pytorch.py \
    --arch-embedding-size=10000000-10000000-10000000-10000000-10000000-10000000-10000000-10000000 \
    --arch-sparse-feature-size=64 --arch-mlp-bot="512-512-64" --arch-mlp-top="1024-1024-1024-1" \
    --data-generation=random --mini-batch-size=2048 --num-batches=100 --num-indices-per-lookup=500 \
    --print-freq=200 --print-time --enable-profiling > auto5.log 2>&1

# numactl python3 dlrm_s_pytorch.py \
#     --arch-embedding-size=10000000-10000000-10000000-10000000-10000000-10000000-10000000-10000000 \
#     --arch-sparse-feature-size=64 --arch-mlp-bot="512-512-64" --arch-mlp-top="1024-1024-1024-1" \
#     --data-generation=random --mini-batch-size=1024 --num-batches=100 --num-indices-per-lookup=100 \
#     --print-freq=200 --print-time --enable-profiling > auto6.log 2>&1

# numactl python3 dlrm_s_pytorch.py \
#     --arch-embedding-size=10000000-10000000-10000000-10000000-10000000-10000000-10000000-10000000 \
#     --arch-sparse-feature-size=64 --arch-mlp-bot="512-512-64" --arch-mlp-top="1024-1024-1024-1" \
#     --data-generation=random --mini-batch-size=512 --num-batches=100 --num-indices-per-lookup=100 \
#     --print-freq=200 --print-time --enable-profiling > auto7.log 2>&1

# numactl python3 dlrm_s_pytorch.py \
#     --arch-embedding-size=10000000-10000000-10000000-10000000-10000000-10000000-10000000-10000000 \
#     --arch-sparse-feature-size=64 --arch-mlp-bot="512-512-64" --arch-mlp-top="1024-1024-1024-1" \
#     --data-generation=random --mini-batch-size=256 --num-batches=100 --num-indices-per-lookup=100 \
#     --print-freq=200 --print-time --enable-profiling > auto_8.log 2>&1

# numactl python3 dlrm_s_pytorch.py \
#     --arch-embedding-size=10000000-10000000-10000000-10000000-10000000-10000000-10000000-10000000 \
#     --arch-sparse-feature-size=64 --arch-mlp-bot="512-512-64" --arch-mlp-top="1024-1024-1024-1" \
#     --data-generation=random --mini-batch-size=128 --num-batches=100 --num-indices-per-lookup=100 \
#     --print-freq=200 --print-time --enable-profiling > auto_9.log 2>&1

# numactl python3 dlrm_s_pytorch.py \
#     --arch-embedding-size=10000000-10000000-10000000-10000000-10000000-10000000-10000000-10000000 \
#     --arch-sparse-feature-size=64 --arch-mlp-bot="512-512-64" --arch-mlp-top="1024-1024-1024-1" \
#     --data-generation=random --mini-batch-size=64 --num-batches=100 --num-indices-per-lookup=100 \
#     --print-freq=200 --print-time --enable-profiling > auto_10.log 2>&1

# numactl python3 dlrm_s_pytorch.py \
#     --arch-embedding-size=10000000-10000000-10000000-10000000-10000000-10000000-10000000-10000000 \
#     --arch-sparse-feature-size=64 --arch-mlp-bot="512-512-64" --arch-mlp-top="1024-1024-1024-1" \
#     --data-generation=random --mini-batch-size=2048 --num-batches=700 --num-indices-per-lookup=100 \
#     --print-freq=200 --print-time --enable-profiling > auto11.log 2>&1

# numactl python3 dlrm_s_pytorch.py \
#     --arch-embedding-size=10000000-10000000-10000000-10000000-10000000-10000000-10000000-10000000 \
#     --arch-sparse-feature-size=64 --arch-mlp-bot="512-512-64" --arch-mlp-top="1024-1024-1024-1" \
#     --data-generation=random --mini-batch-size=2048 --num-batches=900 --num-indices-per-lookup=100 \
#     --print-freq=200 --print-time --enable-profiling > auto12.log 2>&1

numactl python3 dlrm_s_pytorch.py \
    --arch-embedding-size=10000000-10000000-10000000-10000000-10000000-10000000-10000000-10000000 \
    --arch-sparse-feature-size=64 --arch-mlp-bot="512-512-64" --arch-mlp-top="1024-1024-1024-1" \
    --data-generation=random --mini-batch-size=2048 --num-batches=100 --num-indices-per-lookup=700 \
    --print-freq=200 --print-time --enable-profiling > auto13.log 2>&1

numactl python3 dlrm_s_pytorch.py \
    --arch-embedding-size=10000000-10000000-10000000-10000000-10000000-10000000-10000000-10000000 \
    --arch-sparse-feature-size=64 --arch-mlp-bot="512-512-64" --arch-mlp-top="1024-1024-1024-1" \
    --data-generation=random --mini-batch-size=2048 --num-batches=100 --num-indices-per-lookup=900 \
    --print-freq=200 --print-time --enable-profiling > auto14.log 2>&1